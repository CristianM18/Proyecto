import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const resuelve = () => {
  return (
    <View>
      <Text>resuelve</Text>
    </View>
  )
}

export default resuelve

const styles = StyleSheet.create({})