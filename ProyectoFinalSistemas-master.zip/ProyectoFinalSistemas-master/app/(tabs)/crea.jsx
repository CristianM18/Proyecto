import { View, Text } from 'react-native'
import React from 'react'

const Crea = () => {
  return (
    <View>
      <Text>Crea</Text>
    </View>
  )
}

export default Crea